const { Command } = require('discord.js-commando');
const { MessageEmbed } = require("discord.js");

module.exports = class NowPlayingCommand extends Command {
    constructor(client) {
        super(client, {
            name: 'nowplaying',
            aliases: ['np'],
            group: 'audio',
            memberName: 'nowplaying',
            description: 'Display the current song.',
            guildOnly: true,
        });
    }

    run(message) {
        const queue = message.client.queue.get(message.guild.id);
        if (!queue) return message.reply("There is nothing playing.").catch(console.error);
        const song = queue.songs[0];
    
        let nowPlaying = new MessageEmbed()
          .setTitle("Now playing")
          .setDescription(`${song.title}\n${song.url}`)
          .setColor("#F8AA2A")
          .setTimestamp();
    
        if (song.duration > 0) nowPlaying.setFooter(new Date(song.duration * 1000).toISOString().substr(11, 8));
    
        return message.channel.send(nowPlaying);
    }

};